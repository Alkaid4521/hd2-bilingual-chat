Bilingual Chat v1.0.0
addon path: mods/alkaid/bilingual_chat
Log: %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\
