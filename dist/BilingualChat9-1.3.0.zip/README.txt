Bilingual Chat Auto v1.3.0
addon path: mods/dsh/bilingual_chat9
Log: %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\
