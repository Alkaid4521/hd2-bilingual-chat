Bilingual Chat Auto v1.2.0
addon path: mods/dsh/bilingual_chat9
Log: %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\
